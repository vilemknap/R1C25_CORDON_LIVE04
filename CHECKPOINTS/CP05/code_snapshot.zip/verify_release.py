"""Verify the self-contained 2025 release. No COM, no model writes."""
from pathlib import Path
import argparse,hashlib,json,sys
ROOT=Path(__file__).resolve().parent

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def verify(root=ROOT):
    manifest=json.loads((root/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
    failures=[]
    for rec in manifest['files']:
        rel=Path(rec['path'])
        if rel.is_absolute() or '..' in rel.parts:failures.append({'path':str(rel),'reason':'INVALID_RELATIVE_PATH'});continue
        p=root/rel
        if not p.is_file():failures.append({'path':str(rel),'reason':'MISSING'})
        elif p.stat().st_size!=rec['size'] or digest(p)!=rec['sha256']:failures.append({'path':str(rel),'reason':'HASH_OR_SIZE_MISMATCH'})
    config=json.loads((root/'CORDON_2025_CONFIG.json').read_text())
    if config.get('apply') is not False:failures.append({'path':'CORDON_2025_CONFIG.json','reason':'APPLY_MUST_BE_FALSE'})
    if config.get('model_year')!=2025:failures.append({'path':'CORDON_2025_CONFIG.json','reason':'WRONG_MODEL_YEAR'})
    return {'status':'RELEASE_INTEGRITY_PASS' if not failures else 'RELEASE_INTEGRITY_FAIL',
        'release':manifest['release'],'checked_files':len(manifest['files']),'failures':failures,
        'apply_permitted':False,'live_visum_tested':False,'production_ready':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path);a=p.parse_args()
    try:r=verify()
    except Exception as e:r={'status':'RELEASE_INTEGRITY_FAIL','reason':repr(e),'apply_permitted':False}
    text=json.dumps(r,indent=2);print(text)
    if a.output:a.output.write_text(text,encoding='utf-8')
    raise SystemExit(0 if r['status']=='RELEASE_INTEGRITY_PASS' else 1)
