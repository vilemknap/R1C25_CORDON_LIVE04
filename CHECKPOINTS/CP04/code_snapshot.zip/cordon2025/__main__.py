"""Offline CLI. There is deliberately no COM import, discovery or APPLY command."""
from __future__ import annotations
import argparse,json,sys,traceback,datetime
from pathlib import Path
from .common import ROOT,ContractError,require,read_config,new_output,write_json,read_csv,sha256,canonical_hash,deployment_gate
from .authority import audit_workbooks,mapping
from .incidence import build_from_snapshot,aggregate_observations,METHODS
from .budget import from_audit_csv
from .optimizer import solve
from .feasibility import parent_projection,evaluate_realizability,finecdf_availability
from .demos import synthetic_demo


def targets_from_audit():
    target={}
    for row in read_csv(ROOT/'data/audited/PHYSICAL_TARGETS.csv'):
        if row['category']!='OA':continue
        require(int(row['survey_year'])==2026 and row['basis']=='RPDI','TARGET_BASIS_INVALID')
        a,b=int(row['matrix_row_station']),int(row['matrix_column_station'])
        key=(a,b);require(key not in target,'DUPLICATE_TARGET_CELL')
        target[key]=float(row['observed_rpdi'])
    require(len(target)==256,'OA_TARGET_GRID_INCOMPLETE')
    return target


def empirical_run(folder,cfg,cache,evidence_path,propose=False,allow_scenario=False,credit_scenario=False):
    require(cache is not None and Path(cache).is_file(),'NO_2025_PATH_CACHE')
    require(evidence_path is not None and Path(evidence_path).is_file(),'SNAPSHOT_EVIDENCE_REQUIRED')
    evidence=json.loads(Path(evidence_path).read_text(encoding='utf-8'))
    require(evidence.get('origin')=='VISUM_SAVED_PATHS','EMPIRICAL_RUN_REQUIRES_VISUM_SAVED_PATHS_NOT_SYNTHETIC')
    cfg=dict(cfg)
    idx,_=mapping(ROOT/'data/audited/STATION_MAPPING.csv')
    variants=build_from_snapshot(cache,idx,cfg,evidence,hits_output=folder/'STATION_HITS.csv')
    targets=targets_from_audit()
    holdout={tuple(sorted(p)) for p in cfg['validation_unordered_pairs']}
    roles={(a,b):('VALIDATION' if (a,b) in holdout else 'CALIBRATION') for a in range(1,17) for b in range(a+1,17)}
    gate=deployment_gate(cfg,True);summaries=[]
    for method,raw in variants.items():
        out=folder/method;raw.save(out/'DIRECTED_DIAGNOSTICS')
        inc=aggregate_observations(raw,targets,bidirectional=True,roles=roles)
        inc.save(out)
        summary={'method':method,'status':'DIAGNOSTIC_PASS','gate':gate,'observation_semantics_approved':False,
                 'survey_year':2026,'model_year':2025,'prediction_kind':'SAVED_PATH_HYPOTHESIS_NOT_CALIBRATED_RESULT'}
        if propose:
            require(allow_scenario,'UNAPPROVED_OBSERVATION_SEMANTICS_EXPLICIT_SCENARIO_REQUIRED')
            budget=from_audit_csv(ROOT/'data/audited/C17_STATION_BUDGETS.csv',
                [(r['origin_station'],r['destination_station']) for r in inc.rows],
                policy='BOUNDED_SCENARIO' if credit_scenario else 'UNAPPROVED',scenario_authorized=credit_scenario)
            result=solve(inc,cfg,budget,allow_unapproved_scenario=True);result.save(out,inc)
            write_json(out/'TG_TD_PROJECTION.json',parent_projection(inc,result,cfg))
            write_json(out/'FULL_OD_FEASIBILITY.json',evaluate_realizability(inc,result))
            summary['status']=result.report['status'];summary['objective_before']=result.report['objective_initial'];summary['objective_after']=result.report['objective_final']
        summaries.append(summary)
    report={'status':'OFFLINE_HYPOTHESIS_RESULTS','variants':summaries,'gate':gate,'config_sha256':canonical_hash(cfg),
            'cache_sha256':sha256(cache),'snapshot_evidence_sha256':sha256(evidence_path),
            'authority_audit_sha256':sha256(ROOT/'data/audited/AUTHORITY_AUDIT.json'),
            'apply_permitted':False,'live_visum_tested':False,'production_ready':False}
    write_json(folder/'RUN_REPORT.json',report);return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['audit-inputs','preflight','demo','inspect-cache','propose'])
    p.add_argument('--config',type=Path,default=ROOT/'CORDON_2025_CONFIG.json')
    p.add_argument('--run-name',default=None,help='New folder under this release OFFLINE_RESULTS; no external output roots')
    p.add_argument('--cache',type=Path,help='Explicit completed copied SQLite snapshot; never an active WAL database')
    p.add_argument('--evidence',type=Path,help='Snapshot provenance JSON; no automatic 2022 search')
    p.add_argument('--allow-unapproved-scenario',action='store_true')
    p.add_argument('--bounded-c17-scenario',action='store_true')
    args=p.parse_args(argv);folder=None
    try:
        cfg=read_config(args.config)
        name=args.run_name or (args.command.replace('-','_')+'_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S_%f'))
        folder=new_output(name)
        if args.command=='audit-inputs':
            report=audit_workbooks(ROOT/'data/source',folder/'audited')
        elif args.command=='demo':report=synthetic_demo(folder,cfg)
        elif args.command=='preflight':
            report={'status':'NO_2025_PATH_CACHE' if args.cache is None else 'EXPLICIT_CACHE_REQUIRES_INSPECT_CACHE',
                'gate':deployment_gate(cfg,args.cache is not None and args.cache.is_file()),
                'source_scope':'READ_ONLY_STATIC_PREFLIGHT','finecdf_reference':finecdf_availability()}
            write_json(folder/'PREFLIGHT.json',report)
        else:
            require(not args.bounded_c17_scenario or args.allow_unapproved_scenario,'C17_SCENARIO_OPT_IN_REQUIRED')
            report=empirical_run(folder,cfg,args.cache,args.evidence,args.command=='propose',args.allow_unapproved_scenario,args.bounded_c17_scenario)
        write_json(folder/'COMMAND_STATUS.json',{'command':args.command,'status':report.get('status'),'output':str(folder),
            'config_sha256':sha256(args.config),'apply_permitted':False,'live_visum_tested':False})
        print(json.dumps({'status':report.get('status'),'output':str(folder),'apply':False}))
        if args.command=='preflight':return 2
        if report.get('status')=='SYNTHETIC_DEMO_NOT_CONVERGED':return 3
        if any(v.get('status')=='OFFLINE_SOLVER_NOT_CONVERGED' for v in report.get('variants',[])):return 3
        return 0
    except Exception as exc:
        report={'status':'BLOCKED','reason':str(exc),'exception':type(exc).__name__,'apply_permitted':False,'live_visum_tested':False}
        if folder:
            write_json(folder/'COMMAND_STATUS.json',report)
            (folder/'TRACEBACK.txt').write_text(traceback.format_exc(),encoding='utf-8')
        print(json.dumps(report),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
