from __future__ import annotations
import csv
import hashlib
import json
import math
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / 'parent'

def parent_core():
    """Import the bundled fork, refusing an already loaded different 15A2."""
    loaded = sys.modules.get('r1_15a2_core')
    if loaded and Path(loaded.__file__).resolve() != PARENT / 'r1_15a2_core.py':
        raise ContractError('PARENT_MODULE_COLLISION')
    if str(PARENT) not in sys.path:
        sys.path.insert(0, str(PARENT))
    import r1_15a2_core
    return r1_15a2_core

class ContractError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise ContractError(message)

def finite(value, label, nonnegative=True):
    require(not isinstance(value, bool), 'INVALID_NUMBER:' + label)
    try:
        val = float(value)
    except (ValueError, TypeError) as exc:
        raise ContractError('MISSING_OR_INVALID_NUMBER:' + label) from exc
    require(math.isfinite(val) and (not nonnegative or val >= 0), 'INVALID_NUMBER:' + label)
    return val

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def canonical_hash(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def read_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        sample = f.read(8192); f.seek(0)
        return list(csv.DictReader(f, delimiter=';' if sample.count(';') >= sample.count(',') else ','))

def write_json(path, data):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.partial')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False), encoding='utf-8')
    os.replace(tmp, p)

def write_csv(path, rows, fields=None):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    rows = list(rows)
    fields = fields or list(dict.fromkeys(k for row in rows for k in row))
    with p.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter=';'); w.writeheader(); w.writerows(rows)

def read_config(path=None):
    p = Path(path or ROOT/'CORDON_2025_CONFIG.json')
    cfg = json.loads(p.read_text(encoding='utf-8'))
    require(cfg.get('apply') is False, 'V1_APPLY_FORBIDDEN')
    require(cfg.get('mode') == 'OFFLINE_PROPOSAL', 'OFFLINE_MODE_REQUIRED')
    require(cfg.get('model_year') == 2025 and cfg.get('survey_year') == 2026, 'YEAR_CONTRACT_MISSING')
    require(cfg.get('category') == 'OA', 'V1_OA_ONLY')
    return cfg

def new_output(name):
    require(name and name.replace('_','').replace('-','').isalnum(), 'UNSAFE_OUTPUT_NAME')
    p = ROOT/'OFFLINE_RESULTS'/name
    p.mkdir(parents=True, exist_ok=False)
    return p

APPROVAL_FIELDS = ('observation_semantics','direction_mapping','year_bridge','network_mapping',
                   'dseg_scope','geometry_identity','path_volume_parity','c17_policy')
def deployment_gate(cfg, cache_present=False):
    approvals = cfg.get('approvals', {})
    missing = [key.upper() + '_UNAPPROVED' for key in APPROVAL_FIELDS
               if not (isinstance(approvals.get(key), dict) and approvals[key].get('approved') is True
                       and approvals[key].get('evidence_sha256') and approvals[key].get('authority_id'))]
    if not cache_present:
        missing.append('NO_2025_PATH_CACHE')
    return {'blockers': missing + ['NOT_LIVE_TESTED', 'V1_OFFLINE_ONLY'],
            'apply_permitted': False, 'production_ready': False, 'live_visum_tested': False}
