"""2025-only offline cordon extension of R1 15A2; never attaches to Visum."""
__version__ = '1.0.0-offline'
