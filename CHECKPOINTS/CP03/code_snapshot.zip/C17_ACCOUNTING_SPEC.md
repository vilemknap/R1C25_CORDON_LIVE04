# C17 accounting contract - V1

## Evidence versus hypothesis
D2 pre-sym has distinct row/column counts. D3 has a symmetric pair of margins, after expansion. Both columns are retained with cell addresses and hashes. No direction is silently inferred and no 2026 -> 2025 scaling is invented. The return category (vjazd-vyjazd) is excluded from C17. Classification-unrecognised additions in D1 are audited separately and are not added again.

Default policy: UNAPPROVED. Equivalent numerical policy DISABLED: u=0. The known matrix is unchanged. C17 remains in a separate budget report. No physical pair imputation is implemented.

## Optional BOUNDED_SCENARIO
This is a conservative, explicitly opt-in sensitivity relaxation, NOT a production allocation or confidence interval. There is one pooled station account B_s per category/time basis, taken ONCE from the symmetric D3 margin. The row and column are not two independent accounts.

A nonnegative pair relaxation u_(a,b) draws u credits from account a and u credits from account b. Thus R_s=sum_(pairs touching s) u_pair <= B_s. A further global constraint is sum_s R_s=2*sum_pair u_pair <= G, with G<=sum_s B_s. Directional reverse pairs use the SAME pooled accounts. This is a strict credit reservation rule, not a statement that the unknown detections physically refer to both endpoints. No vehicle is attributed by this operation. u is never forced to exhaust the accounts.

Projection uses Dykstra's algorithm with nonnegativity, station-cap halfspaces and global credit cap. Its result is checked for feasibility. The optimizer applies positive consumption regularization and computes consumption afresh for each candidate; budgets are not cumulatively spent by trying candidates. Validation targets do not affect allocation.

The optional eligible_fraction is an explicit scenario parameter, never a rate inferred from D3. Production pair allocation stays disabled even for a successful scenario. Unknown endpoint identification, direction mapping, correlation with known pairs and physical eligibility require separate approved evidence before any future live algorithm.

## Why no +/-C17
u is nonnegative. It only relaxes a model excess over a known physical target. A deficit cannot be hidden using C17. An independent small symmetric epsilon may be tested but defaults to zero. Epsilon is never described as a statistical confidence interval without a sampling/error model.
